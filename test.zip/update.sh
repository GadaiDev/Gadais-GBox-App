rm ./gbox
wget https://github.com/GadaiDev/gbox/raw/main/gbox