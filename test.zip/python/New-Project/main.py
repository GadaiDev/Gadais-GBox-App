import tkinter as tk
import requests
import zipfile
import json
import os
if not os.path.exists("tmp"):
    os.makedirs("tmp")
path_splitted = __file__.split("/")
path_splitted.reverse()
del path_splitted[0]
path_splitted.reverse()
path = "/".join(path_splitted)+"/"
url = json.load(path+"Lib.json")

# zipファイルを開く
class Example():
   def __init__(self) -> None:
        app = input("GBox用アプリケーション名:")
        extracted_dir = f'./python/{app}/'
        f=open(f"./tmp/{app}.zip","w")
        f.write(requests.get(url[app]).content)
        zip_file_path = f'./tmp/{app}.zip'
        with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        # 解凍先ディレクトリが存在しない場合は作成する
            if not os.path.exists(extracted_dir):
                os.makedirs(extracted_dir)

            zip_ref.extractall(extracted_dir)
        os.remove(f"./tmp/{app}.zip")
Example()